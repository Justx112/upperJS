const a = (b) => {
  return 10 + b;
};

module.exports = {
  a
};
